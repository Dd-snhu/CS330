#ifndef SHADER_CLASS_H
#define SHADER_CLASS_H

#include<glad/glad.h>
#include<string>
#include<fstream>
#include<sstream>
#include<iostream>
#include<cerrno>



class Shader {

public:

	//glm::mat4 model = glm::mat4(1.0f);

	// shader program variable
	GLuint ID;

	//makes shader program
	Shader(const char* vertexFile, const char* fragmentFile);


	// activate and delete function for shader program
	void Activate();
	void Delete();

private:
	// Checks if the different Shaders have compiled properly
	void compileErrors(unsigned int shader, const char* type);

};




#endif // !SHADER_CLASS_H

