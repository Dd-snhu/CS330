#ifndef VBO_CLASS_H
#define VBO_CLASS_H

#include<glm/glm.hpp>
#include<glad/glad.h>
#include<vector>

struct Vertex {

	glm::vec3 position;	
	glm::vec3 color;
	glm::vec2 texUV;
	glm::vec3 normal;

	

};

class VBO {

public:

	// variable for VBO
	GLuint ID;

	// makes VBO and links PyrVertices
	VBO(std::vector<Vertex>& vertices);

	// bind VBO
	void Bind();

	// unbind VBO
	void Unbind();

	// delete VBO
	void Delete();

};

#endif
