#ifndef VAO_CLASS_H
#define VAO_CLASS_H


#include<glad/glad.h>
#include"VBO.h"

class VAO {
public:
	// variable to hold VAO information 
	GLuint ID;
	VAO();

	// links vbo information to VAO
	void LinkAttrib(VBO& VBO, GLuint layout, GLuint numComponents, GLenum type, GLsizeiptr stride, void* offset);

	// bind VAO
	void Bind();

	// unbind VAO
	void Unbind();

	// delete VAB
	void Delete();

};

#endif // !VAO_CLASS_H
