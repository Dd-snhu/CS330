#include"shaderClass.h"

// reads text file to string to read settings file
std::string get_file_contents(const char* filename) {
	
	std::ifstream in(filename, std::ios::binary);
	if (in) {

		std::string contents;
		in.seekg(0, std::ios::end);
		contents.resize(in.tellg());
		in.seekg(0, std::ios::beg);
		in.read(&contents[0], contents.size());
		in.close();
		return(contents);
	}

	throw(errno);
}


// builds shader program
Shader::Shader(const char* vertextFile, const char* fragmentFile) {

	// reads vertex and fragmet file 
	std::string vertextCode = get_file_contents(vertextFile);
	std::string fragmentCode = get_file_contents(fragmentFile);

	const char* vertextSource = vertextCode.c_str();
	const char* fragmentSource = fragmentCode.c_str();

	// makes vertex shader and its references
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);		
	glShaderSource(vertexShader, 1, &vertextSource, NULL);		// attaches vertex shader to program 	
	glCompileShader(vertexShader);								//compile vertex shader to machine code
	compileErrors(vertexShader, "VERTEX");

	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER); // make fragment shader
	glShaderSource(fragmentShader, 1, &fragmentSource, NULL);	//attach fragment shader to program
	glCompileShader(fragmentShader);							// compile fragment shader to machine code
	compileErrors(fragmentShader, "FRAGMENT");
	
	

	ID = glCreateProgram();						//make shader program and its variable
	glAttachShader(ID, vertexShader);			//attach vertex shader to program
	glAttachShader(ID, fragmentShader);			// attach fragment shader to program
	glLinkProgram(ID);							// link all shaders together
	compileErrors(ID, "PROGRAM");

	glDeleteShader(vertexShader);				//delete vertex and fragment shaders
	glDeleteShader(fragmentShader);

}

//activates shader program
void Shader::Activate() {
	glUseProgram(ID);
}

// deletes shader program
void Shader::Delete() {
	glUseProgram(ID);

}

// Checks if the different Shaders have compiled properly
void Shader::compileErrors(unsigned int shader, const char* type)
{
	// Stores status of compilation
	GLint hasCompiled;
	// Character array to store error message in
	char infoLog[1024];
	if (type != "PROGRAM")
	{
		glGetShaderiv(shader, GL_COMPILE_STATUS, &hasCompiled);
		if (hasCompiled == GL_FALSE)
		{
			glGetShaderInfoLog(shader, 1024, NULL, infoLog);
			std::cout << "SHADER_COMPILATION_ERROR for:" << type << "\n" << infoLog << std::endl;
		}
	}
	else
	{
		glGetProgramiv(shader, GL_LINK_STATUS, &hasCompiled);
		if (hasCompiled == GL_FALSE)
		{
			glGetProgramInfoLog(shader, 1024, NULL, infoLog);
			std::cout << "SHADER_LINKING_ERROR for:" << type << "\n" << infoLog << std::endl;
		}
	}
}