
/*
#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>


#include"shaderClass.h"
#include"VAO.h"
#include"VBO.h"
#include"EBO.h"


*/
#include<filesystem>
namespace fs = std::filesystem;

#include"stb_image.h"
#include"Mesh.h"
#include "Verticies_indicies.h"
#include"Camera2.h"
#include "Texture.h"





const unsigned int width = 800;
const unsigned int height = 800;

GLuint cubeIndices[]{
	//Top
	0, 1, 2,
	2, 3, 1,

	//Bottom
	4, 5, 6,
	6, 7, 5,

	//Front
	8, 9, 10,
	10, 11, 9,

	//Back
	12, 13, 14,
	14, 15, 13,

	//Left
	16, 17, 18,
	18, 19, 17,

	//Right
	20, 21, 22,
	22, 23, 21

	
};


Vertex cubeVertices[] = {

Vertex{ glm::vec3(-1.0f, 1.0f, -1.0f), glm::vec3(0.9f,  0.96f, 0.02f) }, //top yellow
Vertex{ glm::vec3(1.0f, 1.0f, -1.0f), glm::vec3(0.9f,  0.96f, 0.02f) },
Vertex{ glm::vec3(-1.0f, 1.0f,  1.0f), glm::vec3(0.9f,  0.96f, 0.02f)},
Vertex{ glm::vec3(1.0f, 1.0f,  1.0f), glm::vec3(0.9f,  0.96f, 0.02f) },

Vertex{ glm::vec3(-1.0f, -1.0f, -1.0f), glm::vec3(0.18f,  0.02f, 0.96f)}, //bottom blue
Vertex{glm::vec3(1.0f, -1.0f, -1.0f), glm::vec3(0.18f,  0.02f, 0.96f)},
Vertex{glm::vec3(-1.0f, -1.0f, 1.0f), glm::vec3(0.18f,  0.02f, 0.96f)},
Vertex{glm::vec3(1.0f, -1.0f,  1.0f), glm::vec3(0.18f,  0.02f, 0.96f)},

Vertex{glm::vec3(-1.0f,  1.0f, 1.0f), glm::vec3(1.0f,  0.00f, 00.0f)}, // front red
Vertex{glm::vec3(1.0f,  1.0f, 1.0f), glm::vec3(1.0f,  0.00f, 00.0f)},
Vertex{glm::vec3(-1.0f, -1.0f, 1.0f), glm::vec3(1.0f,  0.00f, 00.0f)},
Vertex{glm::vec3(1.0f, -1.0f, 1.0f), glm::vec3(1.0f,  0.00f, 00.0f)},

Vertex{glm::vec3(-1.0f,  1.0f, -1.0f), glm::vec3(0.90f,  0.12f, 0.75f)}, // back
Vertex{glm::vec3(1.0f,  1.0f, -1.0f), glm::vec3(0.50f,  0.00f, 00.0f)},
Vertex{glm::vec3(-1.0f, -1.0f, -1.0f), glm::vec3(0.00f,  1.00f, 00.0f)},
Vertex{glm::vec3(1.0f, -1.0f, -1.0f), glm::vec3(0.96f,  0.52f, 0.19f)},

Vertex{glm::vec3(-1.0f,  1.0f,  1.0f), glm::vec3(0.00f,  0.00f, 01.0f)}, // left
Vertex{glm::vec3(-1.0f,  1.0f, -1.0f), glm::vec3(0.90f,  0.12f, 0.75f)},
Vertex{glm::vec3(-1.0f, -1.0f,  1.0f), glm::vec3(0.50f,  0.00f, 00.0f)},
Vertex{glm::vec3(-1.0f, -1.0f, -1.0f), glm::vec3(0.00f,  1.00f, 00.0f)},

Vertex{glm::vec3(1.0f,  1.0f,  1.0f), glm::vec3(0.96f,  0.52f, 0.19f)}, // right
Vertex{glm::vec3(1.0f,  1.0f, -1.0f), glm::vec3(0.00f,  0.00f, 01.0f)},
Vertex{glm::vec3(1.0f, -1.0f,  1.0f), glm::vec3(0.90f,  0.12f, 0.75f)},
Vertex{glm::vec3(1.0f, -1.0f, -1.0f), glm::vec3(0.50f,  0.00f, 00.0f)},

	
};



Vertex PyrVertices[] = {

	//					position					color						texture					normal
	Vertex{glm::vec3(-0.5f, 0.0f,  0.5f), glm::vec3(0.00f,  0.00f, 01.0f),  glm::vec2(0.0f, 0.0f), glm::vec3(-0.5f,0.0f,0.5f)},
	Vertex{glm::vec3(-0.5f, 0.0f, -0.5f), glm::vec3(0.00f,  0.00f, 01.0f),  glm::vec2(5.0f, 0.0f), glm::vec3(-0.5f,0.0f,-0.5f)},
	Vertex{glm::vec3(0.5f, 0.0f,  -0.5f), glm::vec3(0.90f,  0.12f, 0.75f),  glm::vec2(0.0f, 0.0f), glm::vec3(0.5f,0.0f,-0.5f)},
	Vertex{glm::vec3(0.5f, 0.0f,   0.5f), glm::vec3(0.50f,  0.00f, 00.0f),  glm::vec2(5.0f, 0.0f), glm::vec3(0.5f,0.0f,0.5f)},
	Vertex{glm::vec3(0.0f, 0.8f,   0.0f), glm::vec3(0.00f,  1.00f, 00.0f),  glm::vec2(2.5f, 5.0f), glm::vec3(0.0f,0.0f,0.0f)},
	
	
};



// Indices for PyrVertices order
GLuint P_Indices[] =
{
	
	0, 1, 2,
	0, 2, 3,
	0, 1, 4,
	1, 2, 4,
	2, 3, 4,
	3, 0, 4,
	
};



Vertex House_Base[]{

	// position										color					texture				normal
	Vertex{glm::vec3(0.6f, 0.0f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,0.0f),glm::vec3(-0.5f,0.0f,0.5f) },   // 0 front bottom line -- right side bottom right
	Vertex{glm::vec3(0.2f, 0.0f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 1
	Vertex{glm::vec3(-0.2f, 0.0f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.5f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 2
	Vertex{glm::vec3(-0.6f, 0.0f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 3 left side  ---  bottom right

	Vertex{glm::vec3(0.6f, 0.0f,  -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4 back bottom line -- right side bottom left
	Vertex{glm::vec3(0.2f, 0.0f, -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 5
	Vertex{glm::vec3(-0.2f, 0.0f, -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 6
	Vertex{glm::vec3(-0.6f, 0.0f,  -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7 left side	---  bottom left

	Vertex{glm::vec3(0.6f, 0.3f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 8 front top line	--- right side top right
	Vertex{glm::vec3(0.2f, 0.3f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9
	Vertex{glm::vec3(-0.2f, 0.3f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10
	Vertex{glm::vec3(-0.6f, 0.3f,  0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11 left side	-- 	top right

	Vertex{glm::vec3(0.6f, 0.3f,  -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 12 back top line -- right side top left
	Vertex{glm::vec3(0.2f, 0.3f, -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 13
	Vertex{glm::vec3(-0.2f, 0.3f, -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 14
	Vertex{glm::vec3(-0.6f, 0.3f,  -0.2f), glm::vec3(1.0f,  1.0f, 1.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 15 left side -- top right
	


};

GLuint House_Indices[]{

	0,12,4, // right end
	0,12,8,
	

	0,1,4, // bottom
	4,5,1,
	1,2,5,
	5,6,2,
	2,6,7,
	2,3,7,

	3,15,7,// left end
	3,15,11,

	8,9,12, // top
	12,13,8,
	9,10,13,
	13,14,10,
	10,14,15,
	10,11,15,

	0,1,8, // front
	8,9,1,
	1,2,9,
	9,10,2,
	2,3,10,
	10,11,3,

	
	12,5,13, // back
	12,5,4,
	13,6,5,
	13,6,14,
	14,7,6,
	14,7,15,

	

};

Vertex RoofVerts[]{

	//Vertex{glm::vec3( 0.6f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f)},   // 0 front top line

	//				position					color							texture				normal
	Vertex{glm::vec3( 0.6f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f),glm::vec3(-0.5f,0.0f,0.5f) },   // 0 front top line
	Vertex{glm::vec3( 0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 1
	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2
	Vertex{glm::vec3(-0.6f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 3

	Vertex{glm::vec3( 0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4 back top line 
	Vertex{glm::vec3( 0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 5
	Vertex{glm::vec3(-0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6
	Vertex{glm::vec3(-0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 7	 

	Vertex{glm::vec3( 0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 8 peak
	Vertex{glm::vec3( 0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10
	Vertex{glm::vec3(-0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11

	Vertex{glm::vec3(0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 1  12
	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2  13
	Vertex{glm::vec3(0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 9   14
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10 15

	Vertex{glm::vec3(0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 5  16
	Vertex{glm::vec3(-0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 6  17 
	Vertex{glm::vec3(0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9   18
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 10 19

	Vertex{glm::vec3(-0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 6  20
	Vertex{glm::vec3(-0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7	 21 
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10 22

	Vertex{glm::vec3(0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4   23
	Vertex{glm::vec3(0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 5  24
	Vertex{glm::vec3(0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 8    25

	
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10 26
	Vertex{glm::vec3(-0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11 27
	Vertex{glm::vec3(-0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6  28
	Vertex{glm::vec3(-0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 7	 29

	
	Vertex{glm::vec3(0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4   30    back top line 
	Vertex{glm::vec3(0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 5  31
	Vertex{glm::vec3(0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 8    32  peak
	Vertex{glm::vec3(0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9   33


	Vertex{glm::vec3(-0.2f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6  34
	Vertex{glm::vec3(-0.6f,  0.3f, -0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 7	 35
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10 36
	Vertex{glm::vec3(-0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11 37




	Vertex{glm::vec3(0.6f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 0  38 front top line right square
	Vertex{glm::vec3(0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 1  39 
	Vertex{glm::vec3(0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},// 8    40
	Vertex{glm::vec3(0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9   41

	Vertex{glm::vec3(0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 1  42 front middle
	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)},  // 2  43
	Vertex{glm::vec3(0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9   44
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10 45 

	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2  46 front left
	Vertex{glm::vec3(-0.6f,  0.3f,  0.2f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 3  47
	Vertex{glm::vec3(-0.2f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10 48
	Vertex{glm::vec3(-0.6f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11 49




};

GLuint Roof_indices[]{

	0,4,8,  //right end
	3,7,11, // left end

	40,39,38, // front right
	40,39,41,

	44,43,42, // front middle
	44,43,45,

	48,47,46, // front left
	48,47,49,


	
	16,19,18,
	16,19,17,
	

	33,30,31,
	33,30,32,

	37,34,35,
	37,34,36,

		
};

/*
Vertex jut_out_verts[]{
	Vertex{glm::vec3(0.0f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f)},// 0 peak
	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.48f, 0.48f, 0.48f)},// 1

	Vertex{glm::vec3(0.2f,  0.3f,  0.3f), glm::vec3(0.95f,  0.95f, 0.95f)}, // 2 far Jut
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3f), glm::vec3(0.95f,  0.95f, 0.95f)},// 3
	Vertex{glm::vec3(0.2f,  0.0f,  0.3f), glm::vec3(0.8f,  0.8f, 0.8f)},// 4
	Vertex{glm::vec3(-0.2f,  0.0f,  0.3f), glm::vec3(0.8f,  0.8f, 0.8f)},// 5

	Vertex{glm::vec3(0.2f,  0.3f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 6 base meet
	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)},// 7
	Vertex{glm::vec3(0.2f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 8
	Vertex{glm::vec3(-0.2f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)},// 9


	Vertex{glm::vec3(0.2f,  0.3f,  0.3f), glm::vec3(0.29f, 0.55f, 0.23f)},//2 10 green peak
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3f), glm::vec3(0.29f, 0.55f, 0.23f)},//3 11
	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.29f, 0.55f, 0.23f)},// 1  12

	Vertex{glm::vec3(0.2f,  0.3f,  0.3f), glm::vec3(0.48f, 0.48f, 0.48f)}, // 2 13 roof meet color
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3f), glm::vec3(0.48f, 0.48f, 0.48f)},// 3 14

	Vertex{glm::vec3(0.1f,  0.2f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 15  new jut
	Vertex{glm::vec3(-0.1f,  0.2f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)},// 16
	Vertex{glm::vec3(0.1f,  0.0f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 17
	Vertex{glm::vec3(-0.1f,  0.0f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)}, //18

	Vertex{glm::vec3(0.1f,  0.2f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 19
	Vertex{glm::vec3(-0.1f,  0.2f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, //20

	Vertex{glm::vec3(0.1f,  0.0f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 21
	Vertex{glm::vec3(-0.1f,  0.0f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)}, //22

	Vertex{glm::vec3(0.1f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 23
	Vertex{glm::vec3(-0.1f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, //24

	Vertex{glm::vec3(0.2f,  0.2f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 25
	Vertex{glm::vec3(-0.2f,  0.2f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, //26

	Vertex{glm::vec3(-0.2f,  0.2f,  0.3f), glm::vec3(0.95f,  0.95f, 0.95f)},// 3 11  27
	Vertex{glm::vec3(0.2f,  0.2f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f)},// 1 12  28

	Vertex{glm::vec3(0.2f,  0.3f,  0.3f), glm::vec3(0.95f,  0.95f, 0.95f)}, // 2 13 29 jut meet white
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3f), glm::vec3(0.95f,  0.95f, 0.95f)},// 3 14 30

	Vertex{glm::vec3(0.2f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 31 
	Vertex{glm::vec3(-0.2f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, //32

	Vertex{glm::vec3(0.2f,  0.2f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, // 33 
	Vertex{glm::vec3(-0.2f,  0.2f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f)}, //34

};

*/

/*

Vertex jut_out_verts[]{

	Vertex{glm::vec3(0.0f,  0.5f,  0.0f), glm::vec3(0.48f, 0.48f, 0.48f), glm::vec2(0.0f,0.0f)}, // 0 duplicate point to make counts match


	Vertex{glm::vec3(0.0f,  0.5f,  0.0f), glm::vec3(0.43f, 0.43f, 0.43f), glm::vec2(0.0f,0.0f)},  // 1 peak in roof color
	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.43f, 0.43f, 0.43f), glm::vec2(0.0f,0.0f)},  // 2 peak

	Vertex{glm::vec3(0.15f,  0.3f,  0.3f), glm::vec3(0.43f, 0.43f, 0.43f), glm::vec2(0.0f,0.0f)},  // 3 top triangle in roof color
	Vertex{glm::vec3(-0.15f,  0.3f,  0.3f), glm::vec3(0.43f, 0.43f, 0.43f), glm::vec2(0.0f,0.0f)}, // 4


	Vertex{glm::vec3(0.15f,  0.3f,  0.2f), glm::vec3(0.43f, 0.43f, 0.43f), glm::vec2(0.0f,0.0f)}, // 5 back top corners of top cube
	Vertex{glm::vec3(-0.15f,  0.3f,  0.2f), glm::vec3(0.43f, 0.43f, 0.43f), glm::vec2(0.0f,0.0f)}, // 6

	Vertex{glm::vec3(-0.15f,  0.15f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 7 bottom front corners of top cube
	Vertex{glm::vec3(0.15f,  0.15f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 8 

	Vertex{glm::vec3(0.1f,  0.0f,  0.3f), glm::vec3(0.7f,  0.7f, 0.7f), glm::vec2(0.0f,0.0f)}, // 9 bottom corners of bottom jut
	Vertex{glm::vec3(-0.1f,  0.0f,  0.3f), glm::vec3(0.7f,  0.7f, 0.7f), glm::vec2(0.0f,0.0f)}, // 10

	Vertex{glm::vec3(0.1f,  0.15f,  0.3f), glm::vec3(0.7f,  0.7f, 0.7f), glm::vec2(0.0f,0.0f)}, // 11 top corners of top jut
	Vertex{glm::vec3(-0.1f,  0.15f,  0.3f), glm::vec3(0.7f,  0.7f, 0.7f), glm::vec2(0.0f,0.0f)},  // 12 

	Vertex{glm::vec3(0.15f,  0.2f,  0.0f), glm::vec3(0.8f,  0.8f, 0.8f), glm::vec2(0.0f,0.0f)},  // 13 back corners of top jut and top cube MAY NEED TO CHANGE with 19
	Vertex{glm::vec3(-0.15f,  0.15f,  0.0f), glm::vec3(0.8f,  0.8f, 0.8f), glm::vec2(0.0f,0.0f)},  // 14 

	Vertex{glm::vec3(-0.2f,  0.0f,  0.0f), glm::vec3(0.8f,  0.8f, 0.8f), glm::vec2(0.0f,0.0f)}, // 15 bottom back left corner of jut

	Vertex{glm::vec3(0.2f,  0.0f,  0.0f), glm::vec3(0.8f,  0.8f, 0.8f), glm::vec2(0.0f,0.0f)}, // 16 bottom back right corner of jut MAY NEED TO SWAP WITH 20

	Vertex{glm::vec3(-0.2f,  0.2f,  0.0f), glm::vec3(0.8f,  0.8f, 0.8f), glm::vec2(0.0f,0.0f)}, // 17 top back corner of left slant

	Vertex{glm::vec3(-0.2f,  0.0f,  0.0f), glm::vec3(0.8f,  0.8f, 0.8f), glm::vec2(0.0f,0.0f)}, // 18 bottom back corner of left slant


	Vertex{glm::vec3(0.2f,  0.2f,  0.0f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 19 potenal swap with 13

	Vertex{glm::vec3(0.2f,  0.0f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 20 portenal swap with 16


	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.29f, 0.55f, 0.23f), glm::vec2(0.0f,0.0f)},  // 2 21 green triagle 
	Vertex{glm::vec3(0.15f,  0.3f,  0.3f), glm::vec3(0.29f, 0.55f, 0.23f), glm::vec2(0.0f,0.0f)},  // 3 22
	Vertex{glm::vec3(-0.15f,  0.3f,  0.3f), glm::vec3(0.29f, 0.55f, 0.23f), glm::vec2(0.0f,0.0f)}, // 4 23

	Vertex{glm::vec3(0.15f,  0.3f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 5  24 back points that meet house in house color
	Vertex{glm::vec3(-0.15f,  0.3f,  0.2f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 6 25

	Vertex{glm::vec3(0.15f,  0.3f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)},  // 3 26 top triangle in house color
	Vertex{glm::vec3(-0.15f,  0.3f,  0.3f), glm::vec3(0.9f,  0.9f, 0.9f), glm::vec2(0.0f,0.0f)}, // 4  27

	Vertex{glm::vec3(2.8f,  -0.01f,  2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f)},  // 28  plane
	Vertex{glm::vec3(-2.8f,  -0.01f,  2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f)}, //   29
	Vertex{glm::vec3(2.8f,  -0.01f,  -2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f)},  // 30
	Vertex{glm::vec3(-2.8f, -0.01f, -2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f)}, //   31

	Vertex{glm::vec3(-0.1f,  0.0f,  0.3f), glm::vec3(0.7f,  0.7f, 0.7f), glm::vec2(0.0f,0.0f)}, // 10

};

GLuint jut_out_ind[]{
	 
	1,4,2, // peak left
	1,4,6,

	1,3,2,// peak right
	1,3,5,

	21,22,23, //green triagle

	27,8,7, // top jut out cube face
	27,8,26,

	12,9,10, // bottom jut small face
	12,9,11,

	17,10,18, // left slant
	17,10,12,

	11,16,9, // right slant
	11,16,13,

	14,27,25, // left side of top cube
	14,27,7,

	8,24,13, // right side of top cube
	8,24,26,

	14,8,7, // top cube bottom
	14,8,13,

	31,28,29,
	31,28,30,

};

*/

Vertex lightVertices[] =
{ //     COORDINATES     //

	
	Vertex{glm::vec3(0.7f, 0.6f,  0.1f)},
	Vertex{glm::vec3(0.7f, 0.6f,  0.0f)},
	Vertex{glm::vec3(0.7f, 0.7f,  0.0f)},
	Vertex{glm::vec3(0.7f, 0.7f,  0.1f)},
	Vertex{glm::vec3(0.8f, 0.6f,  0.1f)},
	Vertex{glm::vec3(0.8f, 0.6f,  0.0f)},
	Vertex{glm::vec3(0.8f, 0.7f,  0.0f)},
	Vertex{glm::vec3(0.8f, 0.7f,  0.1f)}

	
	
};

GLuint lightIndices[] =
{
	0, 1, 2,
	0, 2, 3,
	0, 4, 7,
	0, 7, 3,
	3, 7, 6,
	3, 6, 2,
	2, 6, 5,
	2, 5, 1,
	1, 5, 4,
	1, 4, 0,
	4, 5, 6,
	4, 6, 7
};

Vertex GrassPlaneV[] =
{ 
	//				position						color						texture				normal
	Vertex{glm::vec3(2.8f,  -0.01f,  2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,20.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 0
	Vertex{glm::vec3(-2.8f,  -0.01f,  2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(20.0f,20.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 1
	Vertex{glm::vec3(2.8f,  -0.01f,  -2.48), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2
	Vertex{glm::vec3(-2.8f, -0.01f, -2.48f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(20.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 3
		
};

GLuint GrassPlaneI[] =
{
	0,3,2,
	0,3,1,

};

Vertex jut_out_roof_verts[]{

	Vertex{glm::vec3(0.0f,  0.5f,  0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 0 peak roof
	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 1 peak far
	
	Vertex{glm::vec3(0.2f,  0.0f, 0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2 cube
	Vertex{glm::vec3(-0.2f, 0.0f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 3
	Vertex{glm::vec3(0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4
	Vertex{glm::vec3(-0.2f, 0.3f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 5
	
	Vertex{glm::vec3(0.2f,  0.3f,  0.0), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6 roof triangle inside main cube
	Vertex{glm::vec3(-0.2f, 0.3f, 0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7

	Vertex{glm::vec3(0.0f,  0.5f,  0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 0 8 peak roof
	Vertex{glm::vec3(0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4  9
	Vertex{glm::vec3(0.2f,  0.3f,  0.0), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6  10 roof triangle inside main cube

	Vertex{glm::vec3(0.0f,  0.5f,  0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 0 11 peak roof
	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 1 12 peak far
	Vertex{glm::vec3(-0.2f, 0.3f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 5  13
	Vertex{glm::vec3(-0.2f, 0.3f, 0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7  14

};

GLuint jut_out_roof_ind[]{
	0,4,1, //roof peak right
	8,9,10,

	11,13,12, // roof peak left
	11,13,14,

};

Vertex jut_out_cube_verts[]{

	// top triangle
	Vertex{glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(2.5f,2.5f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 0 peak 
	Vertex{glm::vec3(-0.2f, 0.3f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 1 left top
	Vertex{glm::vec3(0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2  right top

	//right side cube
	Vertex{glm::vec3(0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 3  left top
	Vertex{glm::vec3(0.2f, 0.3f, 0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4 right top
	Vertex{glm::vec3(0.2f,  0.0f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 5  left bottom
	Vertex{glm::vec3(0.2f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6  right bottom

	// front cube
	Vertex{glm::vec3(0.2f, 0.3f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7 right top
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 8  left top
	Vertex{glm::vec3(0.2f, 0.0f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9 right bottom
	Vertex{glm::vec3(-0.2f,  0.f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10  left bottom

	//left side cube
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11  right top
	Vertex{glm::vec3(-0.2f, 0.3f, 0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 12 left top
	Vertex{glm::vec3(-0.2f,  0.0f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 13  right bottom
	Vertex{glm::vec3(-0.2f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 14  left bottom
};


GLuint jut_out_cube_ind[]{

	// top triangle
	//1,2,0,

	//right side cube
	4,5,3,
	4,5,6,

	// front cube
	7,10,9,
	7,10,8,

	// left side cube
	11,14,13,
	11,14,12,

};

Vertex windowsVert[] =
{
	//				position						color						texture				normal
	Vertex{glm::vec3(0.08f,  0.25f, 0.32f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(0.0f, 01.0f, 01.0f)}, // 0
	Vertex{glm::vec3(0.08f,  0.03f, 0.32f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,0.0f), glm::vec3(0.0f, 01.0f, 01.0f)}, // 1
	Vertex{glm::vec3(-0.08f, 0.25f ,0.32f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(00.0f, 01.0f, 01.0f)}, // 2
	Vertex{glm::vec3(-0.08f, 0.03f, 0.32f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(00.0f, 01.0f, 01.0f)}, // 3

	//fixme Fix window position and jutout siding texture  

};

GLuint windowsInd[] =
{
	0,3,2,
	0,3,1,

};

Vertex PorchVert[] =
{
	/*
	//right side
	//					postion					color						texture						normal
	Vertex{glm::vec3(-0.2f,  0.3f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  0 11  left top
	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   1 12 right top
	Vertex{glm::vec3(-0.2f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  2 13  left bottom
	Vertex{glm::vec3(-0.2f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 3 14  right bottom

	// back
	Vertex{glm::vec3(-0.6f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  4 13  left bottom
	Vertex{glm::vec3(-0.6f,  0.3f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 5 14  left top
	Vertex{glm::vec3(-0.2f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6 14  right bottom
	Vertex{glm::vec3(-0.2f,  0.3f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   7 12  right top
	*/
	// roof line
	Vertex{glm::vec3(-0.2f, 0.2f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 8 0 right out
	Vertex{glm::vec3(-0.55f, 0.2f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9 1 left  out
	Vertex{glm::vec3(-0.55f, 0.3f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6 2 left  in
	Vertex{glm::vec3(-0.2f, 0.3f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7 3 right in

	// porch
	Vertex{glm::vec3(-0.2f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 4  right bottom front
	Vertex{glm::vec3(-0.2f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 5  right bottom back
	Vertex{glm::vec3(-0.55f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 6  left  bottom front
	Vertex{glm::vec3(-0.55f,  0.0f,  0.2f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,5.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 7  left  bottom back

	// posts
	// 
	// left post
	// 
	//frontside
	Vertex{glm::vec3(-0.49f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 8  left  bottom 
	Vertex{glm::vec3(-0.51f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9  left  bottom 
	Vertex{glm::vec3(-0.49f,  0.2f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10  left  top
	Vertex{glm::vec3(-0.51f,  0.2f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11 left  top 

	// backside
	Vertex{glm::vec3(-0.49f,  0.0f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 12  left  bottom 
	Vertex{glm::vec3(-0.51f,  0.0f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 13 left  bottom 
	Vertex{glm::vec3(-0.49f,  0.2f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 14 left  top
	Vertex{glm::vec3(-0.51f,  0.2f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 15 left  top 


	// right post

	//front
	Vertex{glm::vec3(-0.3f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 8    16 left  bottom 
	Vertex{glm::vec3(-0.32f,  0.0f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 9   17  left  bottom 
	Vertex{glm::vec3(-0.3f,  0.2f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10   18 left  top
	Vertex{glm::vec3(-0.32f,  0.2f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11  19  left  top 

	// backside
	Vertex{glm::vec3(-0.3f,  0.0f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 12  20 left  bottom 
	Vertex{glm::vec3(-0.32f,  0.0f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 13 21 left  bottom 
	Vertex{glm::vec3(-0.3f,  0.2f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 14  22 left  top
	Vertex{glm::vec3(-0.32f,  0.2f,  0.28f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 15 23 left  top 

	

};

GLuint postsInd[] =
{
	// right post
	16,19,17,
	16,19,18,

	17,23,21,
	17,23,19,

	21,22,20,
	21,22,23,

	16,22,18,
	16,22,20,


	// left post
	8,11,9, // front
	8,11,10,

	9,15,13, // left
	9,15,11,

	13,14,12, // back
	13,14,15,

	8,14,10, // right
	8,14,12,

	





};


GLuint PorchRoofInd[] =
{
	
	0,2,1,
	0,2,3,

};

GLuint PorchbottomInd[] =

{
	4,7,6,
	4,7,5,

};

Vertex GreenTriangleVert[] =
{
	// top triangle
	Vertex{ glm::vec3(0.0f,  0.5f,  0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(2.5f,2.5f), glm::vec3(-0.5f, 0.0f, 0.5f) }, // 0 peak 
	Vertex{ glm::vec3(-0.2f, 0.3f, 0.3f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f) }, // 1 left top
	Vertex{ glm::vec3(0.2f,  0.3f,  0.3), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(5.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f) }, // 2  right top

};

GLuint GreenTriangleIND[] =

{
	0,1,2,

};

Vertex TreeVerts[] =
{
	//				position						color						texture				normal

	// tree base 
	// front
	Vertex{glm::vec3(1.35f,  0.0f,   0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  0
	Vertex{glm::vec3(1.3f,  0.0f,   0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  1	
	// left
	Vertex{glm::vec3(1.25f,  0.0f,   -0.05f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 2
	Vertex{glm::vec3(1.25f,  0.0f, -0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  3
	//back
	Vertex{glm::vec3(1.3f,  0.0f,  -0.15f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  4
	Vertex{glm::vec3(1.35f,  0.0f,  -0.15f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 5
	//right
	Vertex{glm::vec3(1.4f,  0.0f,  -0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   6
	Vertex{glm::vec3(1.4f,  0.0f,  -0.05f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   7
	
	// tree top
	// front
	Vertex{glm::vec3(1.35f,  0.3f,   0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  8
	Vertex{glm::vec3(1.3f,  0.3f,   0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  9	
	// left
	Vertex{glm::vec3(1.25f,  0.3f, -0.05f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 10
	Vertex{glm::vec3(1.25f,  0.3f,  -0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  11
	//back
	Vertex{glm::vec3(1.3f,  0.3f,  -0.15f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  12
	Vertex{glm::vec3(1.35f,  0.3f,  -0.15f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 13
	//right
	Vertex{glm::vec3(1.4f,  0.3f,  -0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   14
	Vertex{glm::vec3(1.4f,  0.3f,  -0.05f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   15

	//Top point
	Vertex{glm::vec3(1.325f,  1.0f,   -0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,0.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   16

	// tree top needles
	// front
	Vertex{glm::vec3(1.4f,  0.3f,   0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  8    17
	Vertex{glm::vec3(1.25f,  0.3f,   0.1f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //  9   18
	// left
	Vertex{glm::vec3(1.15f,  0.3f, 0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //    10  19
	Vertex{glm::vec3(1.15f,  0.3f,  -0.15f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 11  20
	//back
	Vertex{glm::vec3(1.25f,  0.3f,  -0.25f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //12   21
	Vertex{glm::vec3(1.4f,  0.3f,  -0.25f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 13   22
	//right
	Vertex{glm::vec3(1.5f,  0.3f,  -0.15f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(1.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, // 14   23
	Vertex{glm::vec3(1.5f,  0.3f,  0.0f), glm::vec3(0.0f,  0.9f, 0.0f), glm::vec2(0.0f,1.0f), glm::vec3(-0.5f, 0.0f, 0.5f)}, //   15   24
	

};

GLuint TreeTopIND[] =

{
	17,16,18,
	18,16,19,
	19,16,20,
	20,16,21,
	21,16,22,
	22,16,23,
	23,16,24,
	24,16,17,


};

GLuint TreeBaseIND[] =

{
	0,9,1, // front
	0,9,8,

	1,10,2, // left
	1,10,9,
	2,11,3, 
	2,11,10,
	3,12,11,
	3,12,4,

	4,13,5, // back
	4,13,12,

	5,14,13,
	5,14,6,
	6,15,14,
	6,15,7,
	7,8,15,
	7,8,0,
	


};



int main() {

	// start GLFW
	glfwInit();

	// tell GLFW the version numbers of OpenGL and what profile 
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	
	//Create 800 by 800 window
	GLFWwindow* window = glfwCreateWindow(width, height, "3D Pyramid", NULL, NULL);
		
	// terminate window if it fails
	if (window == NULL) {

		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}

	
	// make window the current context
	glfwMakeContextCurrent(window);



	// start and configure OpenGL
	gladLoadGL();


	
	// tell OpenGL our window dimensions 
	glViewport(0, 0, width, height);
	
	
	// Textures
	

	Texture SidingTexture[]{	
		
		Texture("houseSiding2.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};

	Texture RoofTexture[]{

		Texture("shingles.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};


	Texture BrickTexture[]{

		Texture("bricks2.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};

	Texture GrassTexture[]{

		Texture("grass.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};

	Texture WindowTexture[]{

		Texture("window.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};

	Texture GreenSidingTexture[]{

		Texture("greensiding.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};

	Texture TreeBarkTexture[]{

		Texture("pinebark.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};

	Texture TreeNeedlesTexture[]{

		Texture("pineneedles.png", "diffuse", 0, GL_RGBA, GL_UNSIGNED_BYTE)
	};
	
	

	// make shader object
	
	Shader shaderProgram("default.vert", "default2.frag");

	std::vector <Vertex> pyrVerts(PyrVertices, PyrVertices + sizeof(PyrVertices) / sizeof(Vertex));
	std::vector <GLuint> pyrIndices(P_Indices, P_Indices + sizeof(P_Indices) / sizeof(GLuint));
	std::vector <Texture> pyrTex(BrickTexture, BrickTexture + sizeof(BrickTexture) / sizeof(BrickTexture));
		
	//std::vector <Vertex> cubeVerts(cubeVertices, cubeVertices + sizeof(cubeVertices) / sizeof(Vertex));
	//std::vector <GLuint> cubeIndic(cubeIndices, cubeIndices + sizeof(cubeIndices) / sizeof(GLuint));

	//std::vector <Vertex> TriangleV(Triangle_vert, Triangle_vert + sizeof(Triangle_vert) / sizeof(Vertex));
	//std::vector <GLuint> TriangleI(Triangle_inc, Triangle_inc + sizeof(Triangle_inc) / sizeof(GLuint));

	// Home
	
	// house base cube
	std::vector <Vertex> home_base(House_Base, House_Base + sizeof(House_Base) / sizeof(Vertex));
	std::vector <GLuint> home_indic(House_Indices, House_Indices + sizeof(House_Indices) / sizeof(GLuint));
	std::vector <Texture> home_tex(SidingTexture, SidingTexture + sizeof(SidingTexture) / sizeof(SidingTexture));

	// roof
	std::vector <Vertex> roofV(RoofVerts, RoofVerts + sizeof(RoofVerts) / sizeof(Vertex));
	std::vector <GLuint> roofind(Roof_indices, Roof_indices + sizeof(Roof_indices) / sizeof(GLuint));
	std::vector <Texture> roof_tex(RoofTexture, RoofTexture + sizeof(RoofTexture) / sizeof(RoofTexture));

	//Grass plane
	std::vector <Vertex> grassv(GrassPlaneV, GrassPlaneV + sizeof(GrassPlaneV) / sizeof(Vertex));
	std::vector <GLuint> grassind(GrassPlaneI, GrassPlaneI + sizeof(GrassPlaneI) / sizeof(GLuint));
	std::vector <Texture> grass_tex(GrassTexture, GrassTexture + sizeof(GrassTexture) / sizeof(GrassTexture));
	
	// jutout roof
	std::vector <Vertex> jutV_cube(jut_out_cube_verts, jut_out_cube_verts + sizeof(jut_out_cube_verts) / sizeof(Vertex));
	std::vector <GLuint> jutInd_cube(jut_out_cube_ind, jut_out_cube_ind + sizeof(jut_out_cube_ind) / sizeof(GLuint));
	
	//jutout cube
	std::vector <Vertex> jutV(jut_out_roof_verts, jut_out_roof_verts + sizeof(jut_out_roof_verts) / sizeof(Vertex));
	std::vector <GLuint> jutInd(jut_out_roof_ind, jut_out_roof_ind + sizeof(jut_out_roof_ind) / sizeof(GLuint));

	//window
	std::vector <Vertex> windowV(windowsVert, windowsVert + sizeof(windowsVert) / sizeof(Vertex));
	std::vector <GLuint> windowInd(windowsInd, windowsInd + sizeof(windowsInd) / sizeof(GLuint));
	std::vector <Texture> window_tex(WindowTexture, WindowTexture + sizeof(WindowTexture) / sizeof(WindowTexture));

	//porch
	std::vector <Vertex> porchV(PorchVert, PorchVert + sizeof(PorchVert) / sizeof(Vertex));
	std::vector <GLuint> porchroofI(PorchRoofInd, PorchRoofInd + sizeof(PorchRoofInd) / sizeof(GLuint));
	std::vector <GLuint> porchbottomI(PorchbottomInd, PorchbottomInd + sizeof(PorchbottomInd) / sizeof(GLuint));
	std::vector <GLuint> porchpostI(postsInd, postsInd + sizeof(postsInd) / sizeof(GLuint));

	// green triangle
	std::vector <Vertex> greenV(GreenTriangleVert, GreenTriangleVert + sizeof(GreenTriangleVert) / sizeof(Vertex));
	std::vector <GLuint> greenII(GreenTriangleIND, GreenTriangleIND + sizeof(GreenTriangleIND) / sizeof(GLuint));
	std::vector <Texture> greenTex(GreenSidingTexture, GreenSidingTexture + sizeof(GreenSidingTexture) / sizeof(GreenSidingTexture));
	
	// tree 

	std::vector <Vertex> TreeV(TreeVerts, TreeVerts + sizeof(TreeVerts) / sizeof(Vertex));
	std::vector <GLuint> TreeII(TreeBaseIND, TreeBaseIND + sizeof(TreeBaseIND) / sizeof(GLuint));
	std::vector <Texture> TreeTex(TreeBarkTexture, TreeBarkTexture + sizeof(TreeBarkTexture) / sizeof(GreenSidingTexture));
	std::vector <Texture> TreeNeedle(TreeNeedlesTexture, TreeNeedlesTexture + sizeof(TreeNeedlesTexture) / sizeof(TreeNeedlesTexture));
	std::vector <GLuint> TreeTopII(TreeTopIND, TreeTopIND + sizeof(TreeTopIND) / sizeof(GLuint));

	
	// light
	Shader lightShader("light.vert", "light.frag");

	std::vector <Vertex> lightVerts(lightVertices, lightVertices + sizeof(lightVertices) / sizeof(Vertex));
	std::vector <GLuint> lightInd(lightIndices, lightIndices + sizeof(lightIndices) / sizeof(GLuint));

	Mesh light(lightVerts, lightInd, pyrTex);

	Mesh pyramid(pyrVerts, pyrIndices, pyrTex);
	//Mesh cube(cubeVerts, cubeIndic);
	Mesh MainHouseCube(home_base, home_indic, home_tex);
	Mesh Roof(roofV, roofind, roof_tex);
	Mesh JutOutRoof(jutV, jutInd, roof_tex);
	Mesh Grass(grassv, grassind, grass_tex);
	Mesh JutOutCube(jutV_cube, jutInd_cube, home_tex);
	Mesh Window(windowV, windowInd, window_tex);
	Mesh PorchRoof(porchV, porchroofI, roof_tex);
	Mesh PorchBottom(porchV, porchbottomI, home_tex);
	Mesh PorchPosts(porchV, porchpostI, home_tex);
	Mesh GreenTri(greenV, greenII, greenTex);
	Mesh TreeTrunk(TreeV, TreeII, TreeTex);
	Mesh TreeTop(TreeV, TreeTopII, TreeNeedle);

	//Mesh Triangle(TriangleV, TriangleI);
	
	
	
	Camera camera(width, height, glm::vec3(float(width / height), 1.5f, 5.0f));
	glEnable(GL_DEPTH_TEST);

	
	
	//float rotation = 0.0f;
	double prevTime = glfwGetTime();
	float angle = 0.0;
	// loop to watch for events to happen to close window on command
	while (!glfwWindowShouldClose(window)) {
		

		// controls spin of light
		float angleVelocity = glm::radians(45.0f);
		double crntTime = glfwGetTime();

		
		float deltaTime = crntTime - prevTime;
		prevTime = crntTime;

		angle =  angleVelocity * deltaTime;


		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);	// background color
		glClear(GL_COLOR_BUFFER_BIT| GL_DEPTH_BUFFER_BIT);	// clear background and set to our color
		
		
		
		camera.Inputs(window);
		
		// ortho projection      left, right, bottom, top,   near, far,   transx,transy,transz,scale 
		//camera.updateMatrixOrtho(-3.0f,3.0f, -2.0,   5.0f, -2.0, 3.0f, 1.0f, 1.0f, 1.0f, 1.0f);

		
		MainHouseCube.Draw(shaderProgram, camera);
		Roof.Draw(shaderProgram, camera);
		JutOutRoof.Draw(shaderProgram, camera);
		JutOutCube.Draw(shaderProgram, camera);  
		Grass.Draw(shaderProgram, camera);
		Window.Draw(shaderProgram, camera);
		PorchRoof.Draw(shaderProgram, camera);
		PorchBottom.Draw(shaderProgram, camera);
		PorchPosts.Draw(shaderProgram, camera);
		GreenTri.Draw(shaderProgram, camera);
		TreeTrunk.Draw(shaderProgram, camera);
		TreeTop.Draw(shaderProgram, camera);
	

		//Triangle.Draw(shaderProgram, camera);

		//pyramid.Draw(shaderProgram, camera);

		light.Draw(lightShader, camera);

		
		camera.updateMatrixPerspective(90.0f, 0.1f, 100.0f, 1.0f, 1.0f, 1.02f, 1.0f);

		
		
		
		
		if (camera.lampOrbit)
		{
			glm::vec3 rotationAxis(0.0f, 1.0f, 0.0f);
			glm::vec4 newPosition = glm::rotate(angle, rotationAxis) * glm::vec4(camera.lightPos, 1.0f);
			camera.lightPos.x = newPosition.x;
			camera.lightPos.y = newPosition.y;
			camera.lightPos.z = newPosition.z;
			camera.lightModel = glm::rotate(camera.lightModel, angle, rotationAxis);
		}
		

		/*
		if (glfwGetKey(window, GLFW_KEY_TAB) == GLFW_PRESS)
		{

			
			
			if (camera.orthoTrue) {
				camera.updateMatrixPerspective(45.0f, 0.1f, 100.0f, 1.0f, 1.0f, 1.0f, 1.0f);
			}
			
			if (!camera.orthoTrue) {
				camera.updateMatrixOrtho(-3.0f, 3.0f, -2.0, 5.0f, -2.0, 3.0f, 1.0f, 1.0f, 1.0f, 1.0f);
			}
				

		}

		*/
			
		
		glfwSwapBuffers(window);	// swap back buffer to front
		glfwPollEvents(); // watch for GLFW events

	}

	// delete all objects

	
	shaderProgram.Delete();
	lightShader.Delete();
	//bricks.Delete();

	// delete window information 
	glfwDestroyWindow(window);
	// clear GLFW resources 
	glfwTerminate();
	

	return 0;
}

