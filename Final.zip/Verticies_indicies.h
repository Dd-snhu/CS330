#ifndef VERT_IND_DATA_H
#define VER_IND_DATA_H

#include<string>

#include<glad/glad.h>
#include<GLFW/glfw3.h>
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>
#include<glm/gtx/rotate_vector.hpp>
#include<glm/gtx/vector_angle.hpp>

#include"VAO.h"
#include"EBO.h"
#include"Camera2.h"

class Vert_IND_Data {

public:

	std::vector <Vertex> vertices;
	std::vector <GLuint> indices;

};

#endif
