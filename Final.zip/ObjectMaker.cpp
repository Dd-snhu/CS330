/*
#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>

#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>


#include"shaderClass.h"
#include"VAO.h"
#include"VBO.h"
#include"EBO.h"
#include"Camera.h"
*/
#include"ObjectMaker.h"

/*

objectMaker::objectMaker(GLfloat* tempVertices, GLuint* tempIndices) { //, std::string objectName) {

	VAO vaotemp;

	 // make VAO and bind it
	objectMaker::VAO1 = vaotemp;
	objectMaker::VAO1.Bind();
	
	 	
	 // make VBO, EBO, and links to indices
	

	VBO vboTemp(tempVertices, sizeof(tempVertices));
	EBO eboTemp(tempIndices, sizeof(tempIndices));
	objectMaker::VBO1 = vboTemp;
	objectMaker::EBO1 = eboTemp;


	 // link VBO corrdinates and colors to VAO
	objectMaker::VAO1.LinkAttrib(objectMaker::VBO1, 0, 3, GL_FLOAT, 6 * sizeof(float), (void*)0);
	objectMaker::VAO1.LinkAttrib(objectMaker::VBO1, 1, 3, GL_FLOAT, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	 
	objectMaker::VAO1.Unbind();
	
	*/
	

}

*/


 
 /*
 VAO objectMaker::makeObject() {
	 VAO returnVAO = objectMaker::VAO1;
	 
	 return returnVAO;
	   

 }

 */

 


