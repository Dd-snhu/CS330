#include"Camera2.h"
#include<iostream>
//#include "shaderClass.h"

float speed = 0.01f;



// takes scroll input to change speed 
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset) {
	
	
	
		if (yoffset == 1.0) {
			speed += 0.01;
		}

		if (yoffset == -1.0) {

			speed -= 0.01;
		}

		if (speed > 0.5) {
			speed = 0.50;
		}

		if (speed < 0.001) {
			speed = 0.001;
		}

		//std::cout << "yoffset: " << yoffset << std::endl;
		//std::cout << "speed: " << speed << std::endl;
	
}


Camera::Camera(int width, int height, glm::vec3 position)
{
	Camera::width = width;
	Camera::height = height;
	Position = position;
}


void Camera::updateMatrixOrtho(float left, float right, float bottom, float top, float near, float far, float transX, float transY, float transZ, float scale)
{
	orthoTrue = true;
	// Initializes matrices since otherwise they will be the null matrix
	glm::mat4 view = glm::mat4(1.0f);
	glm::mat4 projection = glm::mat4(1.0f);
	glm::mat4 translate = glm::mat4(1.0f);    // ADDED FOR TEST
	glm::mat4 scaleMatrix = glm::mat4(1.0f);

	glm::vec3 scaleVec = glm::vec3(scale, scale, scale);
	// Makes camera look in the right direction from the right position
	view = glm::lookAt(Position, Position + Orientation , Up);
	// Adds perspective to the scene
	projection = glm::ortho(left, right, bottom, top, near, far);

	translate = glm::translate(translate, glm::vec3(transX, transY, transZ));


	// Sets new camera matrix
	cameraMatrix = glm::scale((projection * translate * view), scaleVec);

}


void Camera::updateMatrixPerspective(float FOVdeg, float nearPlane, float farPlane, float transX, float transY, float transZ, float scale)
{
	orthoTrue = false;
	// Initializes matrices since otherwise they will be the null matrix
	
	glm::mat4 view = glm::mat4(1.0f);
	glm::mat4 projection = glm::mat4(1.0f);
	glm::mat4 translate = glm::mat4(1.0f);    // ADDED FOR TEST
	glm::mat4 scaleMatrix = glm::mat4(1.0f);
	

	glm::vec3 scaleVec = glm::vec3(scale, scale, scale);
	// Makes camera look in the right direction from the right position
	view = glm::lookAt(Position, Position + Orientation, Up);
	// Adds perspective to the scene
	projection = glm::perspective(glm::radians(FOVdeg), (float)width / height, nearPlane, farPlane);

	translate = glm::translate(translate,glm::vec3(transX, transY, transZ));
	
	//Shader::model = glm::translate(translate,glm::vec3(0.5f, 0.5f, 0.5f) * scaleVec);
	
	// Sets new camera matrix
	cameraMatrix = glm::scale((projection * translate * view), scaleVec);
	
}





void Camera::Matrix(Shader& shader, const char* uniform)
{
	// Exports camera matrix
	glUniformMatrix4fv(glGetUniformLocation(shader.ID, uniform), 1, GL_FALSE, glm::value_ptr(cameraMatrix));
}



void Camera::Inputs(GLFWwindow* window) //, float speed)
{

	


	// take scroll input and pass to be processed to speed
glfwSetScrollCallback(window, UMouseScrollCallback);


	// Handles key inputs
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		Position += speed * Orientation;
	}
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
	{
		Position += speed * -glm::normalize(glm::cross(Orientation, Up));
	}
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		Position += speed * -Orientation;
	}
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
	{
		Position += speed * glm::normalize(glm::cross(Orientation, Up));
	}
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
	{
		Position += speed * Up;
	}
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
	{
		Position += speed * -Up;
	}
	if (glfwGetKey(window, GLFW_KEY_TAB) == GLFW_PRESS)
	{
		if (Camera::orthoTrue) {

			Camera::updateMatrixPerspective(45.0f, 0.1f, 100.0f, 1.0f, 1.0f, 1.0f, 1.0f);
			Camera::orthoTrue = false;

		}


		
		if (!Camera::orthoTrue) {
			Camera::updateMatrixOrtho(-3.0f, 3.0f, -2.0, 5.0f, -2.0, 3.0f, 1.0f, 1.0f, 1.0f, 1.0f);
			Camera::orthoTrue = true;
		}
	}

	//FIXME

	static bool isLKeyDown = false;
	if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS && !lampOrbit)
		lampOrbit = true;
	else if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS && lampOrbit)
		lampOrbit = false;

	
	// Handles mouse inputs
	if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
	{
		// Hides mouse cursor
		glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

		// Prevents camera from jumping on the first click
		if (firstClick)
		{
			glfwSetCursorPos(window, (width / 2), (height / 2));
			firstClick = false;
		}

		// Stores the coordinates of the cursor
		double mouseX;
		double mouseY;
		// Fetches the coordinates of the cursor
		glfwGetCursorPos(window, &mouseX, &mouseY);

		// Normalizes and shifts the coordinates of the cursor such that they begin in the middle of the screen
		// and then "transforms" them into degrees 
		float rotX = sensitivity * (float)(mouseY - (height / 2)) / height;
		float rotY = sensitivity * (float)(mouseX - (width / 2)) / width;

		// Calculates upcoming vertical change in the Orientation
		glm::vec3 newOrientation = glm::rotate(Orientation, glm::radians(-rotX), glm::normalize(glm::cross(Orientation, Up)));

		// Decides whether or not the next vertical Orientation is legal or not
		if (abs(glm::angle(newOrientation, Up) - glm::radians(90.0f)) <= glm::radians(85.0f))
		{
			Orientation = newOrientation;
		}


		// Rotates the Orientation left and right
		Orientation = glm::rotate(Orientation, glm::radians(-rotY), Up);

		// Sets mouse cursor to the middle of the screen so that it doesn't end up roaming around
		glfwSetCursorPos(window, (width / 2), (height / 2));
					
		
	}


	else if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_RELEASE)
	{
		// Unhides cursor since camera is not looking around anymore
		glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
		// Makes sure the next time the camera looks around it doesn't jump
		firstClick = true;
	}

	

	
}



