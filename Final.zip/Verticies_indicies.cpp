#include"Mesh.h"

#include<glad/glad.h>
#include<GLFW/glfw3.h>
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>
#include<glm/gtx/rotate_vector.hpp>
#include<glm/gtx/vector_angle.hpp>

#include"Verticies_indicies.h"

/*
Vert_IND_Data::vertices(std::vector<Vertex> Triangle[] = {

	Vertex{glm::vec3(-0.5f, 0.0f,  0.0f), glm::vec3(0.00f,  0.00f, 01.0f)},
	Vertex{glm::vec3(0.5f, 0.0f, -0.f), glm::vec3(0.90f,  0.12f, 0.75f)},
	Vertex{glm::vec3(0.0f, 0.5f, 0.0f), glm::vec3(0.50f,  0.00f, 00.0f)},
	

}

GLuint Triangle[] =
{
	0, 1, 2,
	
};

*/